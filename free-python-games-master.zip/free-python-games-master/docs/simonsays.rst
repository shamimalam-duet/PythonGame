Simon Says
==========

A game of watching and recalling patterns.

.. literalinclude:: ../src/freegames/simonsays.py
