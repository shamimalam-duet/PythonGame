.. include:: ../README.rst

.. toctree::
   :hidden:

   give-gift-python
   curriculum
   api
   development
   guess
   snake
   crypto
   illusion
   paint
   maze
   flappy
   bagels
   tictactoe
   ant
   simonsays
   cannon
   bounce
   pong
   life
   tron
   typing
   tiles
   connect
   memory
   minesweeper
   avoid
   pacman
   fidget
   madlibs
   rps
