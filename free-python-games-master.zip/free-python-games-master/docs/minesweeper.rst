Minesweeper
===========

Minesweeper, a logic puzzle game to clear the hidden mines.

.. literalinclude:: ../src/freegames/minesweeper.py
