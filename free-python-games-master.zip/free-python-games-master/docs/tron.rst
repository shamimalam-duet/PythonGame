Tron
====

Tron, classic arcade game.

.. literalinclude:: ../src/freegames/tron.py
