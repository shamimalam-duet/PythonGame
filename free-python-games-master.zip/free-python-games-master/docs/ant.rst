Ant
===

Ant, simple animation demo.

.. literalinclude:: ../src/freegames/ant.py
