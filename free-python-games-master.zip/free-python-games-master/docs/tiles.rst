Tiles
=====

Tiles, number swapping game.

.. literalinclude:: ../src/freegames/tiles.py
