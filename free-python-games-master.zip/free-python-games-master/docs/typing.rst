Typing
======

Typing, simple typing game.

.. literalinclude:: ../src/freegames/typing.py
