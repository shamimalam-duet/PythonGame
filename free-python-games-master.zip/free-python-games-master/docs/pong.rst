Pong
====

Pong, classic arcade game.

.. literalinclude:: ../src/freegames/pong.py
