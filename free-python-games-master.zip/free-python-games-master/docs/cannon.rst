Cannon
======

Cannon, hitting targets with projectiles.

.. literalinclude:: ../src/freegames/cannon.py
