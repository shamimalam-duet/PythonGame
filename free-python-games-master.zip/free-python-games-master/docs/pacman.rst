Pacman
======

Pacman, classic arcade game.

.. literalinclude:: ../src/freegames/pacman.py
