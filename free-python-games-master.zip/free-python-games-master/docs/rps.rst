Rock, Paper, Scissors
=====================

Rock, Paper, Scissors -- classic hand-to-hand combat game.

.. literalinclude:: ../src/freegames/rps.py
