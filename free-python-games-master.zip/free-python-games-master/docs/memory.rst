Memory
======

Memory, puzzle game of number pairs.

.. literalinclude:: ../src/freegames/memory.py
