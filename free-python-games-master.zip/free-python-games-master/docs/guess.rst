Guess
=====

Guess a number within a range.

.. literalinclude:: ../src/freegames/guess.py
