Life
====

Game of Life simulation.

.. literalinclude:: ../src/freegames/life.py
