Fidget
======

Fidget, inspired by fidget spinners.

.. literalinclude:: ../src/freegames/fidget.py
