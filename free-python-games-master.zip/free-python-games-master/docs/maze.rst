Maze
====

Maze, move from one side to another.

.. literalinclude:: ../src/freegames/maze.py
