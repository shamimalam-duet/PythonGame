Snake
=====

Snake, classic arcade game.

.. literalinclude:: ../src/freegames/snake.py
