Avoid
======

Avoid, classic arcade game.

.. literalinclude:: ../src/freegames/avoid.py
