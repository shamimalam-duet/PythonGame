Paint
=====

Paint, for drawing shapes.

.. literalinclude:: ../src/freegames/paint.py
