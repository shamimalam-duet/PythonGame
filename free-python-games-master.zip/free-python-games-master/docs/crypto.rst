Crypto
======

Crypto: tool for encrypting and decrypting messages.

.. literalinclude:: ../src/freegames/crypto.py
