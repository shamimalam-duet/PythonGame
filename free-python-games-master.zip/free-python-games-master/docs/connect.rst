Connect Four
============

Connect Four, two-player connection game.

.. literalinclude:: ../src/freegames/connect.py
