Mad Libs
========

Create a funny story from a not-so funny story

.. literalinclude:: ../src/freegames/madlibs.py
