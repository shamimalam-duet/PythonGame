Bagels
======

Bagels, a number puzzle game.

.. literalinclude:: ../src/freegames/bagels.py
