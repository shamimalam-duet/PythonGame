Illusion
========

An optical illusion.

.. literalinclude:: ../src/freegames/illusion.py
