Flappy
======

Flappy, game inspired by Flappy Bird.

.. literalinclude:: ../src/freegames/flappy.py
