Tic Tac Toe
===========

A paper-and-pencil game for two players.

.. literalinclude:: ../src/freegames/tictactoe.py
